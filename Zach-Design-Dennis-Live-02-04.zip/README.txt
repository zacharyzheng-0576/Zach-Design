Zach Design · Dennis 网站交互 · 三组 Live Photo

02 About me 弹性圆形按钮
03 页尾邮箱磁吸按钮
04 Let’s work together 页尾层次滚动

每组的同名 JPG 与 MOV 是配对资源，必须共同保留。MP4 仅供预览。
在 Mac 照片里同时导入配对文件，确认显示一个可播放的 Live Photo 后，再从照片分享给 iPhone。
本轮 macOS 配对与成片视觉检查已通过；iPhone 与小红书实际导入尚未验证。
来源：https://dennissnellenberg.com/
原站设计与开发：Dennis Snellenberg。
